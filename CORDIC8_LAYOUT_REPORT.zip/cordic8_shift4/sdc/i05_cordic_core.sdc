###############################################################################
# Created by write_sdc
###############################################################################
current_design i05_cordic_core
###############################################################################
# Timing Constraints
###############################################################################
create_clock -name clk -period 10.0000 [get_ports {clk}]
set_propagated_clock [get_clocks {clk}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {angle[0]}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {angle[1]}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {angle[2]}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {angle[3]}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {angle[4]}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {angle[5]}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {angle[6]}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {angle[7]}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {rst_n}]
set_input_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {start}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {busy}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {cos_out[0]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {cos_out[1]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {cos_out[2]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {cos_out[3]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {cos_out[4]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {cos_out[5]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {cos_out[6]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {cos_out[7]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {done}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {sin_out[0]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {sin_out[1]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {sin_out[2]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {sin_out[3]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {sin_out[4]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {sin_out[5]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {sin_out[6]}]
set_output_delay 1.0000 -clock [get_clocks {clk}] -add_delay [get_ports {sin_out[7]}]
###############################################################################
# Environment
###############################################################################
###############################################################################
# Design Rules
###############################################################################
